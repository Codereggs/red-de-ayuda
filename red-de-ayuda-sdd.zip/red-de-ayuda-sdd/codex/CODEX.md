# Codex Instructions — Red de Ayuda

You are implementing **Red de Ayuda** from the SDD harness.

Read these first:

- `spec/README.md`
- `spec/02-business-rules.md`
- `spec/03-architecture.md`
- `spec/04-database-model.md`
- `spec/05-security-and-permissions.md`
- `spec/14-implementation-checklist.md`

## Implementation Rules

- Use Next.js App Router.
- Use TypeScript strict.
- Use React Query for reads.
- Use Server Actions for mutations.
- Use Repository Pattern for Supabase access.
- Use Axios for API calls.
- Use React Hook Form + Zod.
- Use Tailwind.
- Use dark mode only.
- UI text in Spanish.
- Code/database names in English.
- Avoid `any`.
- No public sign-up.
- No hard delete.
- No private data leaks.

## Preferred Flow

1. Implement database + RLS.
2. Implement auth/profile guards.
3. Implement repositories.
4. Implement public UI.
5. Implement dashboard.
6. Implement admin tools.
7. Run checklist.
