-- Red de Ayuda MVP RLS Policies
-- Run after schema.sql.

alter table public.profiles enable row level security;
alter table public.situation_categories enable row level security;
alter table public.need_categories enable row level security;
alter table public.help_types enable row level security;
alter table public.cases enable row level security;
alter table public.case_private_data enable row level security;
alter table public.case_phones enable row level security;
alter table public.assistance_methods enable row level security;
alter table public.case_needs enable row level security;
alter table public.help_records enable row level security;
alter table public.help_record_needs enable row level security;
alter table public.assistance_method_access_logs enable row level security;
alter table public.audit_logs enable row level security;
alter table public.webhook_events enable row level security;

create or replace function public.current_profile_role()
returns text
language sql
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid() and status = 'active';
$$;

create or replace function public.is_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid()
      and status = 'active'
      and role = 'admin'
  );
$$;

create or replace function public.is_helper_or_admin()
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.profiles
    where id = auth.uid()
      and status = 'active'
      and role in ('admin', 'helper')
  );
$$;

create or replace function public.is_public_case(case_uuid uuid)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.cases
    where id = case_uuid
      and status = 'active'
      and verified = true
      and archived_at is null
      and deleted_at is null
  );
$$;

-- profiles
create policy "profiles_select_self_or_admin" on public.profiles
for select using (id = auth.uid() or public.is_admin());

create policy "profiles_admin_all" on public.profiles
for all using (public.is_admin()) with check (public.is_admin());

-- catalogs
create policy "situation_categories_public_select" on public.situation_categories
for select using (deleted_at is null);

create policy "situation_categories_internal_write" on public.situation_categories
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

create policy "need_categories_public_select" on public.need_categories
for select using (deleted_at is null);

create policy "need_categories_internal_write" on public.need_categories
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

create policy "help_types_public_select" on public.help_types
for select using (deleted_at is null);

create policy "help_types_internal_write" on public.help_types
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- cases
create policy "cases_public_select_active" on public.cases
for select using (
  status = 'active'
  and verified = true
  and archived_at is null
  and deleted_at is null
);

create policy "cases_internal_all" on public.cases
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- private case data
create policy "case_private_data_internal_all" on public.case_private_data
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- phones
create policy "case_phones_public_select_for_public_cases" on public.case_phones
for select using (deleted_at is null and public.is_public_case(case_id));

create policy "case_phones_internal_all" on public.case_phones
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- assistance methods
-- No public SELECT. All public access to assistance data goes through the
-- server-side reveal endpoint (service role), which validates, rate-limits,
-- and logs every view. This prevents bypassing the access log via direct
-- Supabase client queries.
create policy "assistance_methods_internal_all" on public.assistance_methods
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- case needs
create policy "case_needs_public_select_for_public_cases" on public.case_needs
for select using (deleted_at is null and public.is_public_case(case_id));

create policy "case_needs_internal_all" on public.case_needs
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- help records
create policy "help_records_public_select_for_public_cases" on public.help_records
for select using (deleted_at is null and public.is_public_case(case_id));

create policy "help_records_internal_all" on public.help_records
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- help record needs
create policy "help_record_needs_public_select" on public.help_record_needs
for select using (
  exists (
    select 1
    from public.help_records hr
    join public.cases c on c.id = hr.case_id
    where hr.id = help_record_id
      and hr.deleted_at is null
      and c.status = 'active'
      and c.verified = true
      and c.archived_at is null
      and c.deleted_at is null
  )
);

create policy "help_record_needs_internal_all" on public.help_record_needs
for all using (public.is_helper_or_admin()) with check (public.is_helper_or_admin());

-- access logs
create policy "assistance_method_access_logs_insert_public" on public.assistance_method_access_logs
for insert with check (true);

create policy "assistance_method_access_logs_admin_select" on public.assistance_method_access_logs
for select using (public.is_admin());

-- audit logs
create policy "audit_logs_admin_select" on public.audit_logs
for select using (public.is_admin());

create policy "audit_logs_internal_insert" on public.audit_logs
for insert with check (public.is_helper_or_admin());

-- webhook events
create policy "webhook_events_admin_select" on public.webhook_events
for select using (public.is_admin());

create policy "webhook_events_internal_insert" on public.webhook_events
for insert with check (public.is_helper_or_admin());

create policy "webhook_events_admin_update" on public.webhook_events
for update using (public.is_admin()) with check (public.is_admin());
