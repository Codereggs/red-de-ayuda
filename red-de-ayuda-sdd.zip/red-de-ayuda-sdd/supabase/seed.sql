-- Red de Ayuda MVP Seed
-- This seed assumes at least one admin profile exists.
-- Replace placeholder ID number and bank data before production use.

do $$
declare
  admin_id uuid;
  situation_id uuid;
  need_olmesartan_40 uuid;
  need_olmesartan_20 uuid;
  need_amlodipina uuid;
  need_levotiroxina uuid;
  mayreth_case_id uuid;
begin
  select id into admin_id from public.profiles where role = 'admin' and status = 'active' limit 1;

  insert into public.situation_categories (name, normalized_name, created_by_user_id)
  values ('Damnificada', 'damnificada', admin_id)
  on conflict (normalized_name) do update set name = excluded.name
  returning id into situation_id;

  insert into public.need_categories (name, normalized_name, created_by_user_id)
  values ('Olmesartan 40mg', 'olmesartan 40mg', admin_id)
  on conflict (normalized_name) do update set name = excluded.name
  returning id into need_olmesartan_40;

  insert into public.need_categories (name, normalized_name, created_by_user_id)
  values ('Olmesartan 20mg', 'olmesartan 20mg', admin_id)
  on conflict (normalized_name) do update set name = excluded.name
  returning id into need_olmesartan_20;

  insert into public.need_categories (name, normalized_name, created_by_user_id)
  values ('Amlodipina 5mg', 'amlodipina 5mg', admin_id)
  on conflict (normalized_name) do update set name = excluded.name
  returning id into need_amlodipina;

  insert into public.need_categories (name, normalized_name, created_by_user_id)
  values ('Levotiroxina 200mg', 'levotiroxina 200mg', admin_id)
  on conflict (normalized_name) do update set name = excluded.name
  returning id into need_levotiroxina;

  insert into public.cases (
    case_type,
    full_name,
    situation_category_id,
    public_notes,
    public_contact_place,
    country,
    state,
    city,
    status,
    verified,
    created_by_user_id
  ) values (
    'person',
    'Mayreth Izturriaga',
    situation_id,
    'Caso registrado para recibir ayuda por situación de damnificada.',
    'Liceo Carlos Fiol, en Marapa Marina',
    'Venezuela',
    'La Guaira',
    'Marapa Marina',
    'active',
    true,
    admin_id
  ) returning id into mayreth_case_id;

  insert into public.case_private_data (
    case_id,
    id_number,
    previous_full_address,
    current_full_address,
    verification_notes,
    private_notes
  ) values (
    mayreth_case_id,
    'V-00000000',
    'Estado La Guaira, localidad Marapa Marina, calle/casa pendiente por confirmar',
    'Liceo Carlos Fiol, Marapa Marina',
    'Caso cargado inicialmente para prueba del MVP. Datos sensibles incompletos deben ser confirmados por helpers.',
    'Seed inicial. Completar cédula y direcciones reales antes de usar en producción.'
  );

  insert into public.case_phones (case_id, phone, label, is_primary)
  values
    (mayreth_case_id, '04242938593', 'Teléfono principal', true),
    (mayreth_case_id, '04166314314', 'Teléfono alternativo', false);

  insert into public.case_needs (case_id, need_category_id, quantity, unit, comments, created_by_user_id)
  values
    (mayreth_case_id, need_olmesartan_40, 1, 'caja', null, admin_id),
    (mayreth_case_id, need_olmesartan_20, 1, 'caja', null, admin_id),
    (mayreth_case_id, need_amlodipina, 1, 'caja', null, admin_id),
    (mayreth_case_id, need_levotiroxina, 1, 'caja', null, admin_id);

  insert into public.assistance_methods (
    case_id,
    type,
    label,
    is_primary,
    is_active,
    holder_full_name,
    id_number,
    phone,
    bank_name,
    account_number,
    account_type,
    previous_full_address,
    current_full_address,
    notes
  ) values (
    mayreth_case_id,
    'bank_transfer',
    'Datos para transferencia',
    true,
    true,
    'Mayreth Izturriaga',
    'V-00000000',
    '04242938593',
    'PENDIENTE',
    'PENDIENTE',
    'PENDIENTE',
    'Estado La Guaira, localidad Marapa Marina, calle/casa pendiente por confirmar',
    'Liceo Carlos Fiol, Marapa Marina',
    'Completar datos bancarios reales antes de usar en producción.'
  );
end $$;
