# Implementation Prompt

You are implementing **Red de Ayuda**, a Next.js + Supabase MVP.

Read all files in this SDD harness before coding:

```txt
spec/README.md
spec/01-product-vision.md
spec/02-business-rules.md
spec/03-architecture.md
spec/04-database-model.md
spec/05-security-and-permissions.md
spec/06-public-website.md
spec/07-helper-panel.md
spec/08-admin-panel.md
spec/09-api-and-webhooks.md
spec/10-ui-ux.md
spec/11-development-rules.md
spec/12-seed-data.md
spec/13-roadmap.md
spec/14-implementation-checklist.md
supabase/schema.sql
supabase/policies.sql
supabase/seed.sql
```

## Non-Negotiable Rules

- UI must be in Spanish.
- Code/database must be in English.
- Use Next.js App Router.
- Use TypeScript strict mode.
- Use Supabase Auth and RLS.
- Use React Query for reads/cache.
- Use Server Actions for mutations.
- Use Axios for API calls.
- Use React Hook Form + Zod for forms.
- Use Tailwind CSS.
- Dark mode only.
- Feature-based FLUX-style architecture.
- Lightweight Repository Pattern.
- No public sign-up.
- No hard delete for important records.
- Public help records are anonymous.
- Assistance data view/copy must be logged.
- Never expose service role key to client.
- Never store raw IP addresses.

## Build Order

1. Create project structure.
2. Configure Supabase clients.
3. Configure React Query provider.
4. Implement auth login and route guards.
5. Implement repositories.
6. Implement public cases API/list/detail.
7. Implement help modal/reveal/copy logging.
8. Implement dashboard layout.
9. Implement case CRUD with forms.
10. Implement needs and assistance methods.
11. Implement mark-as-helped flow.
12. Implement admin users/logs pages.
13. Implement dashboard KPIs.
14. Run QA against checklist.

## Output Expectations

Prefer incremental commits/steps.

Do not invent new product requirements unless necessary.

If something is ambiguous, choose the simplest interpretation consistent with the SDD.
