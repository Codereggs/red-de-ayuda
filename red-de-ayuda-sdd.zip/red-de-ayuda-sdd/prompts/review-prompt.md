# Review Prompt

Review the implementation of **Red de Ayuda** against the SDD harness.

Check for:

- UI copy in Spanish.
- Code/database names in English.
- RLS enabled and policies present.
- Public data does not leak private data.
- Assistance method view/copy logging works.
- Help records are anonymous publicly.
- Admin/helper identity is private.
- Forms use React Hook Form + Zod.
- Reads use React Query.
- Mutations use Server Actions.
- Supabase access goes through repositories.
- Dark mode only.
- Duplicate detection with debounce.
- Archive requires confirmation and reason.
- No hard deletes for important entities.
- Public list randomizes per API request.
- Infinite scroll works.
- Search highlights matches.
- Seed case works.

Return:

1. Critical issues.
2. Security issues.
3. Product rule violations.
4. Architecture deviations.
5. Missing MVP items.
6. Suggested fixes.
