# Claude Instructions — Red de Ayuda

You are working on **Red de Ayuda**.

Before modifying code, read the SDD files in `/spec`, `/supabase`, and `/prompts`.

For all UI work, follow the design system rules in `claude/DESIGN_SYSTEM.md`. This file is authoritative for colors, typography, component patterns, spacing, and Tailwind conventions.

## Priority

Follow the SDD over assumptions.

## Rules

- UI copy must be Spanish.
- Code and database must be English.
- Use feature-based FLUX-style architecture.
- Use React Query for reads.
- Use Server Actions for writes.
- Use repositories for Supabase access.
- Use React Hook Form + Zod for forms.
- Use Tailwind CSS.
- Dark mode only.
- No public registration.
- No hard delete for important data.
- Never leak private data in public routes.
- Public help records are anonymous.
- Assistance method access must be logged.

## When Implementing

Work in small steps.

After each step, verify against `spec/14-implementation-checklist.md`.

If uncertain, choose the simplest secure implementation.
