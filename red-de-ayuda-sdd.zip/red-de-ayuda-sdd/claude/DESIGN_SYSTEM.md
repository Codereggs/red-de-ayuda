# Design System — Red de Ayuda (Puente)

A soft, human, and accessible visual system for the app that connects sponsors (padrinos) with people who need support (recipients).

---

## Absolute implementation rules

- **All styling goes in inline Tailwind classes.** Zero custom CSS outside the theme.
- **Tailwind v4+**: always use native classes. Do not use arbitrary values `[]` if a native class exists.
- **`size-*` instead of `w-* h-*`** when both dimensions are equal. Examples:
  - `size-4` not `w-4 h-4`
  - `size-8` not `w-8 h-8`
  - `size-px` not `w-px h-px`
- **Exception**: if width and height differ, use `w-*` and `h-*` separately.
- **No `style={{ ... }}`** for layout, color, spacing, or typography. The only accepted exception is `fontFamily` until fonts are configured as Tailwind classes in the theme.
- **No arbitrary color classes**: never `bg-[#B5704A]`, always `bg-primary`.
- Use Tailwind opacity modifiers: `bg-primary/10`, `text-foreground/80`, not hex with alpha.
- **No dark mode active in UI**: the app is dark-mode-only (see CLAUDE.md), but the design system defines tokens only in `:root`.

---

## Color palette — Semantic tokens

Tokens are declared as CSS variables and exposed to the Tailwind theme via `@theme inline`. Always use them by **semantic name**.

| Tailwind token           | Hex value             | Name            | Usage                                     |
|--------------------------|-----------------------|-----------------|-------------------------------------------|
| `background`             | `#FAF7F2`             | Warm cream      | Main app background                       |
| `foreground`             | `#2C1F14`             | Deep earth      | Primary text                              |
| `card`                   | `#FDFAF6`             | Earth white     | Card and panel backgrounds                |
| `card-foreground`        | `#2C1F14`             | —               | Text inside cards                         |
| `primary`                | `#B5704A`             | Soft terracotta | Action color, helpers/sponsors            |
| `primary-foreground`     | `#FAF7F2`             | —               | Text on primary                           |
| `secondary`              | `#E4EBE1`             | Pale sage       | Recipient/person surfaces                 |
| `secondary-foreground`   | `#2C4A2E`             | Dark green      | Text on secondary                         |
| `muted`                  | `#EDE8E0`             | Warm linen      | Rest backgrounds, soft separators         |
| `muted-foreground`       | `#7A6555`             | Soft cocoa      | Secondary text, placeholders, meta        |
| `accent`                 | `#E8C9B5`             | Dusty rose      | Connection moments between roles          |
| `accent-foreground`      | `#2C1F14`             | —               | Text on accent                            |
| `destructive`            | `#C05A44`             | Earth red       | Errors and destructive actions            |
| `destructive-foreground` | `#FAF7F2`             | —               | Text on destructive                       |
| `border`                 | `rgba(44,31,20,0.10)` | Earth stroke    | Component borders                         |
| `input-background`       | `#F0EBE3`             | —               | Form field backgrounds                    |
| `ring`                   | `#B5704A`             | —               | Input focus ring                          |
| `chart-1`                | `#B5704A`             | Terracotta      | Primary data                              |
| `chart-2`                | `#7A9E7E`             | Mid sage        | Success, recipients in charts             |
| `chart-3`                | `#D4A574`             | Golden wheat    | Tertiary data, warm neutral               |
| `chart-4`                | `#8B7355`             | Cedar           | Quaternary data                           |
| `chart-5`                | `#C4845C`             | Friendly copper | Quinary data                              |
| `sidebar`                | `#F5F0E8`             | —               | Sidebar background                        |

### Semantic color use by role

- **Helpers / Sponsors** → `primary` (terracotta): represents those who give. Use `bg-primary`, `text-primary`, `border-primary/20`, `ring-primary/50`.
- **Persons / Recipients** → `secondary` + `chart-2` (sage): represents those who receive. Use `bg-secondary`, `text-secondary-foreground`, `ring-chart-2/50`.
- **Bond / Connection** → `accent` (dusty rose): moments of encounter between both roles.
- **Neutrals / Structure** → `muted`, `muted-foreground`, `border`.

---

## Typography

Three families with strict purposes. Apply with `font-*` if configured in the theme, or with `style={{ fontFamily: 'var(--font-display)' }}` as a temporary fallback.

| CSS variable     | Family                           | Usage                                        |
|------------------|----------------------------------|----------------------------------------------|
| `--font-display` | `'Lora', Georgia, serif`         | Titles, headings, emotional claims           |
| `--font-body`    | `'Nunito', system-ui, sans-serif`| All UI text: labels, paragraphs, buttons     |
| `--font-mono`    | `'DM Mono', monospace`           | IDs, dates, data, metadata, code             |

### Font loading (Google Fonts)

```
Lora: ital,wght@0,400;0,500;0,600;1,400;1,500
Nunito: wght@300;400;500;600;700
DM Mono: wght@400;500
```

### Type scale

**Display (Lora — `--font-display`)**

| Tailwind class              | Size | Weight        | Usage                               |
|-----------------------------|------|---------------|-------------------------------------|
| `text-5xl font-medium`      | 48px | medium (500)  | Main hero, onboarding               |
| `text-4xl font-medium`      | 36px | medium        | Page titles                         |
| `text-3xl font-normal`      | 30px | regular       | Large section titles                |
| `text-2xl font-medium`      | 24px | medium        | Subtitles, secondary claims         |
| `text-2xl font-medium italic` | 24px | medium italic | Phrases with emotional emphasis   |

**Body (Nunito — `--font-body`)**

| Tailwind class         | Size | Usage                                        |
|------------------------|------|----------------------------------------------|
| `text-lg font-normal`  | 18px | Featured paragraphs, intro sections          |
| `text-base font-normal`| 16px | Regular text                                 |
| `text-sm font-normal`  | 14px | Secondary text, descriptions                 |
| `text-sm font-semibold`| 14px | Form labels, usernames                       |
| `text-xs font-semibold`| 12px | Badge labels, captions, metadata labels      |

**Mono (DM Mono — `--font-mono`)**

| Tailwind class                        | Usage                                         |
|---------------------------------------|-----------------------------------------------|
| `text-sm`                             | IDs, emails, amounts, dates with time         |
| `text-xs`                             | Timestamps in notifications, secondary meta   |
| `text-[10px]`                         | Only when absolutely necessary (e.g. version in header) |
| `tracking-[0.15em] uppercase`         | Section eyebrow labels                        |

### Typography rules

- `leading-tight` on headlines (`text-3xl` and above).
- `leading-relaxed` on body paragraphs.
- `tracking-tight` only on logo/brand mark.
- Eyebrow labels: `text-xs font-semibold tracking-[0.15em] uppercase text-muted-foreground mb-5` with `--font-mono`.
- Do not use `font-bold` except for CTA buttons on primary background (`bg-primary-foreground text-primary`).

---

## Border radius

Base radius is `--radius: 1rem` (equivalent to `rounded-2xl` when `--radius-lg = 1rem`).

| Token         | Calculated value        | Equivalent Tailwind class           |
|---------------|-------------------------|-------------------------------------|
| `--radius-sm` | `calc(1rem - 4px)` = 12px | `rounded-xl`                      |
| `--radius-md` | `calc(1rem - 2px)` = 14px | `rounded-[14px]` (if needed)      |
| `--radius-lg` | `1rem` = 16px           | `rounded-2xl`                       |
| `--radius-xl` | `calc(1rem + 4px)` = 20px | `rounded-3xl`                     |

**Radius conventions by component type:**

- Cards: `rounded-2xl`
- Buttons: `rounded-full`
- Inputs: `rounded-xl`
- Badges / pills: `rounded-full`
- Avatars: `rounded-full`
- Icon containers: `rounded-xl` (small) or `rounded-2xl` (medium)
- Hero sections: `rounded-3xl`
- Empty states: `rounded-3xl`
- Panels / modals: `rounded-2xl`
- Notification items: `rounded-xl`

---

## Shadows

Only subtle, contextual shadows. Never dark or pronounced ones.

- Card hover (helper): `hover:shadow-md hover:shadow-primary/8`
- Card hover (recipient): `hover:shadow-md hover:shadow-chart-2/10`
- Primary button: `shadow-sm shadow-primary/20`
- Always pair with `transition-shadow duration-300`.

---

## Components

### Button

```
Base:    inline-flex items-center gap-2 font-semibold rounded-full transition-all duration-200 cursor-pointer select-none
Sizes:
  sm:    px-4 py-1.5 text-sm
  md:    px-6 py-2.5 text-sm
  lg:    px-8 py-3.5 text-base
Variants:
  primary:   bg-primary text-primary-foreground hover:bg-primary/85 active:scale-[0.98] shadow-sm shadow-primary/20
  secondary: bg-secondary text-secondary-foreground hover:bg-secondary/70 border border-secondary-foreground/10
  ghost:     text-foreground hover:bg-muted
  outline:   border border-primary text-primary hover:bg-primary/8
```

- Only one `primary` button per section.
- CTA buttons on a primary background use `bg-primary-foreground text-primary font-bold`.
- With icon: icon comes before text, `size-4`.

### Badge

```
Base:  inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-semibold
Variants:
  helper:    bg-primary/10 text-primary border border-primary/20
  recipient: bg-secondary text-secondary-foreground border border-secondary-foreground/15
  active:    bg-chart-2/15 text-[#2C4A2E] border border-chart-2/30
  pending:   bg-accent text-foreground border border-accent-foreground/15
  success:   bg-chart-2/20 text-[#1D3820] border border-chart-2/30
  neutral:   bg-muted text-muted-foreground border border-border
```

### Avatar

```
Base:   rounded-full overflow-hidden flex items-center justify-center font-semibold bg-accent text-foreground/70 shrink-0
Sizes:
  sm:   size-8 text-xs
  md:   size-10 text-sm
  lg:   size-14 text-base
  xl:   size-20 text-xl
Rings:
  helper:    ring-2 ring-primary/50 ring-offset-2 ring-offset-background
  recipient: ring-2 ring-chart-2/50 ring-offset-2 ring-offset-background
```

- Shows initials (max 2 letters) when no image is available.
- Image: `<img className="size-full object-cover" />`

### Input / Form field

```
Label:  text-sm font-semibold text-foreground/80
Input:  w-full px-4 py-2.5 rounded-xl border border-border bg-input-background text-foreground
        placeholder:text-muted-foreground text-sm
        focus:outline-none focus:ring-2 focus:ring-primary/30 transition-all
```

- Wrapper: `flex flex-col gap-1.5`
- No custom color styles on the input element, only semantic tokens.

### Card (base)

```
bg-card border border-border rounded-2xl p-5 flex flex-col gap-4
```

- Helper card hover: `hover:shadow-md hover:shadow-primary/8 transition-shadow duration-300`
- Recipient card hover: `hover:shadow-md hover:shadow-chart-2/10 transition-shadow duration-300`

### StatCard

```
bg-card border border-border rounded-2xl p-5 flex flex-col gap-3
Icon container: size-9 rounded-xl flex items-center justify-center + accent color
Value:  text-2xl font-semibold text-foreground (font-display)
Label:  text-sm text-muted-foreground mt-0.5
```

### NotificationItem

```
Unread: flex items-start gap-3 px-4 py-3 rounded-xl bg-accent/40
Read:   flex items-start gap-3 px-4 py-3 rounded-xl hover:bg-muted transition-colors
Icon:   size-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0 mt-0.5
Message: text-sm text-foreground leading-relaxed
Time:    text-xs text-muted-foreground mt-1 (font-mono)
Unread dot: size-2 rounded-full bg-primary mt-1.5 shrink-0
```

### ProgressBar

```
Wrapper:    flex flex-col gap-1.5
Header row: flex justify-between items-center
  Label:    text-sm text-foreground/80
  Value:    text-xs text-muted-foreground (font-mono)
Track:      h-2 bg-muted rounded-full overflow-hidden
Fill:       h-full rounded-full transition-all duration-700 + semantic color
```

### ConnectionCard (Helper ↔ Recipient)

```
bg-card border border-border rounded-2xl p-5 flex items-center gap-4
Names:  text-sm font-semibold text-foreground truncate
Icon:   Heart size-3.5 text-primary shrink-0 (fill="currentColor")
Meta:   text-xs text-muted-foreground mt-0.5 (font-mono)
```

### Divider

```jsx
<div className="border-t border-border my-14" />
```

### Section eyebrow label

```
text-xs font-semibold tracking-[0.15em] uppercase text-muted-foreground mb-5
font: --font-mono
```

### Section title

```
text-2xl font-medium text-foreground mb-2
font: --font-display
```

### Hero / CTA panel

```
bg-primary rounded-3xl p-8 md:p-12 relative overflow-hidden
Title:    text-3xl md:text-4xl font-medium text-primary-foreground leading-tight (font-display)
Subtext:  text-primary-foreground/75 text-sm leading-relaxed
CTA btn:  bg-primary-foreground text-primary px-6 py-2.5 rounded-full text-sm font-bold
          inline-flex items-center gap-2 hover:bg-primary-foreground/90 transition-all
Ghost btn: text-primary-foreground/80 text-sm font-semibold hover:text-primary-foreground
           inline-flex items-center gap-2 transition-colors
```

### Empty state

```
bg-card border border-dashed border-border rounded-3xl p-12
flex flex-col items-center text-center gap-4 max-w-sm mx-auto
Icon:     size-16 rounded-full bg-accent flex items-center justify-center
Title:    font-semibold text-foreground text-base (font-display)
Subtext:  text-sm text-muted-foreground mt-1.5 leading-relaxed
CTA link: text-sm text-primary font-semibold hover:underline underline-offset-2
          flex items-center gap-1
```

---

## Layout and spacing

- **Main container**: `max-w-5xl mx-auto px-6`
- **Page padding**: `py-12`
- **Gap between sections**: `space-y-14` or `my-14`
- **Card grid gap**: `gap-4`
- **Color/stat grid gap**: `gap-3`
- **Card padding**: `p-5`
- **Panel padding**: `p-6`

### Responsive grids

```
2 columns:   grid grid-cols-2 md:grid-cols-2
4 columns:   grid grid-cols-2 md:grid-cols-4
Color swatch: grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4
```

---

## Icons

Use the `lucide-react` library. Native sizes with `size-*`:

| Context                  | Class        |
|--------------------------|--------------|
| Icon in button           | `size-4`     |
| Inline icon in text      | `size-3` or `size-3.5` |
| Icon in notification     | `size-4`     |
| Icon in StatCard         | `size-4`     |
| Icon in empty state      | `size-7`     |
| Logo / brand mark        | `size-4`     |

---

## Header / Navigation

```
sticky top-0 z-30 bg-background/90 backdrop-blur-sm border-b border-border
Inner:        max-w-5xl mx-auto px-6 py-4 flex items-center justify-between
Brand logo:   size-8 rounded-full bg-primary flex items-center justify-center
Nav tab active:   px-3.5 py-1.5 rounded-full text-sm font-semibold bg-primary text-primary-foreground
Nav tab inactive: px-3.5 py-1.5 rounded-full text-sm font-semibold text-muted-foreground
                  hover:text-foreground hover:bg-muted transition-all duration-200
```

---

## Animations and transitions

- Buttons: `transition-all duration-200`
- Card hover: `transition-shadow duration-300`
- Active button press: `active:scale-[0.98]`
- Progress bar fill: `transition-all duration-700`
- Color hover: `transition-colors`
- No elaborate animations or spring physics. Keep `duration` between 150–700ms.

---

## Forbidden patterns

| ❌ Don't                     | ✅ Do instead                   |
|------------------------------|---------------------------------|
| `w-4 h-4`                    | `size-4`                        |
| `w-8 h-8`                    | `size-8`                        |
| `bg-[#B5704A]`               | `bg-primary`                    |
| `text-[#7A6555]`             | `text-muted-foreground`         |
| `style={{ color: '#B5704A' }}`| `className="text-primary"`     |
| `style={{ backgroundColor: ... }}` | semantic Tailwind class    |
| Global CSS classes for layout | inline Tailwind everywhere     |
| `rounded-[16px]`             | `rounded-2xl`                   |
| `p-[20px]`                   | `p-5`                           |
| `gap-[12px]`                 | `gap-3`                         |
| Arbitrary spacing if native scale exists | native scale (4px = 1 unit) |

---

## CSS token quick reference

```
--background:         #FAF7F2   /* warm cream */
--foreground:         #2C1F14   /* deep earth */
--card:               #FDFAF6   /* cards */
--primary:            #B5704A   /* terracotta · helpers */
--primary-foreground: #FAF7F2
--secondary:          #E4EBE1   /* sage · recipients */
--secondary-foreground: #2C4A2E
--muted:              #EDE8E0   /* linen · rest */
--muted-foreground:   #7A6555   /* cocoa · secondary */
--accent:             #E8C9B5   /* dusty rose · bond */
--accent-foreground:  #2C1F14
--destructive:        #C05A44
--border:             rgba(44,31,20,0.10)
--input-background:   #F0EBE3
--ring:               #B5704A
--chart-2:            #7A9E7E   /* mid sage · recipients/success */
--chart-3:            #D4A574   /* wheat · warm neutral */
--radius:             1rem      /* generous corners */

--font-display: 'Lora', Georgia, serif
--font-body:    'Nunito', system-ui, sans-serif
--font-mono:    'DM Mono', monospace
```
