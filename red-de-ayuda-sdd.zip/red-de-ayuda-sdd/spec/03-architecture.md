# 03 — Architecture

## Architectural Style

Use a small-app architecture based on:

- Feature-based organization.
- FLUX-style unidirectional data flow.
- React Query for reads/cache.
- Server Actions for mutations.
- Lightweight Repository Pattern for Supabase access.
- Zod validation.
- React Hook Form for forms.

Do not use formal heavy DDD for the MVP.

## Data Flow

```txt
UI
 ↓
React Hook Form / User Action
 ↓
Server Action / Query Hook
 ↓
Repository
 ↓
Supabase
 ↓
React Query Cache Invalidation
 ↓
UI
```

## Reads

Use React Query for client-side data fetching and caching.

Public list/detail can use Server Components where beneficial, but interactive filters/infinite loading should use React Query.

## Mutations

Use Server Actions for authenticated writes:

- Create/edit/archive cases.
- Create/edit assistance methods.
- Create/edit needs.
- Register help records.
- Create dynamic catalog items.
- Log sensitive assistance method views/copies.

## Repository Pattern

Each feature must expose repositories that hide Supabase implementation details.

Example:

```txt
features/cases/repositories/cases.repository.ts
features/needs/repositories/needs.repository.ts
features/help-records/repositories/help-records.repository.ts
```

Repositories should:

- Accept typed input.
- Return typed output.
- Avoid leaking raw Supabase responses to UI.
- Throw or return typed errors consistently.

## Monorepo-Ready

Use a structure that can later move to a monorepo, but do not overcomplicate the MVP.

Suggested package manager: `pnpm`.

## Folder Structure

```txt
src/
  app/
    (public)/
      page.tsx
      someone/[id]/page.tsx

    (auth)/
      login/page.tsx

    dashboard/
      page.tsx
      cases/
        page.tsx
        new/page.tsx
        [id]/page.tsx
      users/
        page.tsx
      logs/
        page.tsx

  features/
    cases/
      components/
      actions/
      queries/
      repositories/
      schemas/
      types/
      utils/

    needs/
      components/
      actions/
      queries/
      repositories/
      schemas/
      types/

    help-records/
      components/
      actions/
      queries/
      repositories/
      schemas/
      types/

    assistance-methods/
      components/
      actions/
      queries/
      repositories/
      schemas/
      types/

    users/
      components/
      actions/
      queries/
      repositories/
      schemas/
      types/

    audit-logs/
      repositories/
      types/

  shared/
    components/
    lib/
    hooks/
    utils/
    constants/
```

## Naming Rules

- Database tables: snake_case, English.
- Database columns: snake_case, English.
- TypeScript files: kebab-case.
- React components: PascalCase.
- Variables/functions: camelCase, English.
- UI labels/copy: Spanish.

## Auth

Use Supabase Auth.

Users are created manually in Supabase for the MVP.

The app must have a `profiles` table linked to `auth.users`.

## Styling

Use Tailwind CSS.

Dark mode only.

Avoid multiple themes in MVP.

## UI Components

Use simple reusable components:

- Button
- Input
- Textarea
- Select/Combobox
- Modal
- Drawer
- Toast
- Skeleton
- Badge
- Card
- Table
- EmptyState
- ConfirmDialog

## State

Do not add Redux/Zustand unless absolutely necessary.

Use:

- React Query for server state.
- React Hook Form for form state.
- Local component state for UI interactions.

## Error Handling

All Server Actions must return a typed result shape:

```ts
type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string; fieldErrors?: Record<string, string[]> };
```

## Validation

Use Zod schemas shared between forms and Server Actions wherever possible.
