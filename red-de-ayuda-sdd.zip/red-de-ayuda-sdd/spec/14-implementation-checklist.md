# 14 — Implementation Checklist

## Phase 1 — Project Setup

- [ ] Create Next.js app with TypeScript.
- [ ] Configure Tailwind CSS.
- [ ] Configure dark mode only.
- [ ] Install Supabase client/server helpers.
- [ ] Install React Query.
- [ ] Install Axios.
- [ ] Install React Hook Form.
- [ ] Install Zod.
- [ ] Create environment variables.

## Phase 2 — Supabase

- [ ] Run `supabase/schema.sql`.
- [ ] Run `supabase/policies.sql`.
- [ ] Create first Supabase Auth admin manually.
- [ ] Insert matching `profiles` row.
- [ ] Run `supabase/seed.sql` for dev.

## Phase 3 — Shared Infrastructure

- [ ] Supabase server client.
- [ ] Supabase browser client.
- [ ] Axios instance.
- [ ] React Query provider.
- [ ] ActionResult type.
- [ ] IP hash utility.
- [ ] Auth helpers.
- [ ] Role guard helpers.

## Phase 4 — Features

- [ ] Cases repository.
- [ ] Needs repository.
- [ ] Assistance methods repository.
- [ ] Help records repository.
- [ ] Users repository.
- [ ] Audit logs repository.
- [ ] Public API repository.

## Phase 5 — Public UI

- [ ] Public grid.
- [ ] Infinite scroll.
- [ ] Filters.
- [ ] Search with highlight.
- [ ] Public case card.
- [ ] Public detail.
- [ ] Help modal.
- [ ] Assistance reveal flow.
- [ ] Copy public card.
- [ ] Copy assistance data.

## Phase 6 — Auth + Dashboard

- [ ] Login page.
- [ ] Dashboard layout.
- [ ] Dashboard KPIs.
- [ ] Private cases list.
- [ ] Global private search.
- [ ] Create case form.
- [ ] Edit case form.
- [ ] Duplicate detection.
- [ ] Archive flow.
- [ ] Mark as helped modal.

## Phase 7 — Admin

- [ ] Users page.
- [ ] Access logs page.
- [ ] Audit logs page.

## Phase 8 — Integrations

- [ ] Webhook event storage.
- [ ] Email provider abstraction.
- [ ] WhatsApp copy text.

## Phase 9 — QA

- [ ] Public cannot see archived cases.
- [ ] Public cannot see private notes.
- [ ] Public cannot see helper identity.
- [ ] Assistance reveal logs view action.
- [ ] Assistance copy logs copy action.
- [ ] Duplicate detection works.
- [ ] Save disabled until valid.
- [ ] Archive requires reason.
- [ ] Search highlights matches.
