# 07 — Helper Panel

## Routes

```txt
/dashboard
/dashboard/cases
/dashboard/cases/new
/dashboard/cases/[id]
```

## Helper Dashboard

MVP dashboard should show at least:

- Active cases count.
- Archived cases count.
- Total help records count.
- Total registered USD amount.
- Cases without help count.
- Recent cases.
- Recent help records.

This is considered MVP because it helps operational visibility.

## Cases List

Private cases list must support global search by:

- Name.
- UUID.
- Public code.
- ID number.
- Bank.
- Phone.
- Situation.
- Need.
- Location.

All matches must be highlighted.

Filters:

- Status.
- Type.
- State.
- City.
- Situation.
- Need.

## Create/Edit Case Form

Use:

- React Hook Form.
- Zod.
- Save button disabled until valid.
- Duplicate detection with debounce.

### Required Fields

Case data:

- Case type: `person` or `family`.
- Full name.
- Situation category.
- Public contact place.
- Country, default `Venezuela`.
- State.
- City.

Private data:

- ID number.
- Previous full address.
- Current full address.
- Birth date optional.
- Verification notes.
- Private notes optional.

Phones:

- At least one Venezuelan phone.
- Optional label.
- One can be primary.

Needs:

- At least one need.
- Need category.
- Quantity required.
- Unit optional.
- Comments optional.

Assistance methods:

- At least one active method.
- Label required.
- Type required.
- Holder full name required.
- ID number required.
- Phone required.
- Bank name required for bank/pago methods.
- Account number required for bank transfer.
- Account type required for bank transfer.
- Previous full address required.
- Current full address required.

## Duplicate Detection UX

For fields:

- ID number.
- Phones.
- Assistance method phones.

Show status near the input:

```txt
✓ Disponible
```

or

```txt
✕ Posible duplicado
```

If duplicate exists:

- Show matching case summary.
- Disable save until helper confirms continuation.

## Dynamic Catalog UX

For these fields:

- Situation.
- Needs.
- Help type.

Use searchable combobox/tag input.

If value exists, select it.

If not, allow creating it.

Normalize internally to lowercase and deduplicate by normalized name.

## Mark as Helped

Each case need should have a button:

```txt
Marcar ayuda
```

This opens modal:

Fields:

- Help type.
- Associated needs, multiple select.
- Title.
- Description.
- Amount USD optional.
- Helped at manual date.
- Private notes optional.

Saving creates:

- `help_records`.
- `help_record_needs`.
- `audit_logs` entry.

It does not close or complete the need.

## Archive Case

Archive requires modal confirmation with:

- Case summary.
- Mandatory archive reason.
- Confirm button.

Archiving sets:

- `status = 'archived'`
- `archived_at`
- `archived_by_user_id`
- `archive_reason`

Archived cases disappear from public UI.

## Helper Restrictions

Helpers cannot:

- Manage profiles.
- Change roles.
- See admin-only logs if restricted.
