# Red de Ayuda — SDD Harness

This folder contains the Software Design Document harness for **Red de Ayuda**.

The goal is to give Codex, Claude, or any implementation agent a precise product and technical specification to build the MVP with minimal ambiguity.

## Product Summary

**Red de Ayuda** is a verified aid registry for people and family groups in Venezuela. Helpers and admins register active verified cases, their needs, available assistance methods, and anonymous help records. The public can browse active cases, filter by needs/location/situation, copy a public card, and view assistance data only after a responsible-use confirmation.

## MVP Stack

- Next.js App Router
- TypeScript
- Supabase Auth
- Supabase PostgreSQL
- Supabase RLS
- React Query
- Axios
- React Hook Form
- Zod
- Tailwind CSS
- Dark mode only
- Spanish UI
- English code/database
- Feature-based FLUX-style architecture
- Lightweight Repository Pattern

## File Index

```txt
spec/
  README.md
  01-product-vision.md
  02-business-rules.md
  03-architecture.md
  04-database-model.md
  05-security-and-permissions.md
  06-public-website.md
  07-helper-panel.md
  08-admin-panel.md
  09-api-and-webhooks.md
  10-ui-ux.md
  11-development-rules.md
  12-seed-data.md
  13-roadmap.md
  14-implementation-checklist.md

supabase/
  schema.sql
  policies.sql
  seed.sql

prompts/
  implementation-prompt.md
  review-prompt.md

claude/
  CLAUDE.md

codex/
  CODEX.md
```

## Golden Rules

1. UI copy must be in Spanish.
2. Code, database tables, columns, variables, and functions must be in English.
3. Public users can only see active verified non-archived cases.
4. Private data is only visible to authenticated active admins/helpers.
5. Assistance methods are shown publicly only after clicking the help flow.
6. Every view/copy of assistance method data must be logged.
7. Help records are always anonymous publicly.
8. Admins/helpers can privately see who registered a help record.
9. Nothing should be hard-deleted. Use soft delete / archive where applicable.
10. MVP supports only two case types: `person` and `family`.
```
