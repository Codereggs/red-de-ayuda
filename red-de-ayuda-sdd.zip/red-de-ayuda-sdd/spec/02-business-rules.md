# 02 — Business Rules

## Roles

### Public Visitor

Can:

- View active verified public cases.
- Filter/search cases.
- Open a case detail page.
- Click `Ayudar`.
- View public case data.
- Reveal assistance methods after responsible-use text.
- Copy assistance data.
- Copy public case card.

Cannot:

- Create cases.
- Register help.
- See admin/helper identity.
- See private notes.
- Edit anything.

### Helper

Can:

- Login.
- View all cases.
- Create cases.
- Edit cases.
- Archive cases.
- View private data.
- Register help records.
- Manage needs for a case.
- Manage assistance methods for a case.
- See duplicate warnings.

Cannot:

- Manage users.
- Change roles.
- Access admin-only tracking dashboards if restricted.

### Admin

Can do everything a helper can, plus:

- Manage helper/admin profiles.
- Activate/inactivate users.
- View admin access logs.
- View who registered help records.
- View audit logs.

## Case Types

Only these case types are allowed in the MVP:

```txt
person
family
```

No organizations in MVP.

## Case Status

Only these case statuses are allowed:

```txt
active
archived
```

Archived cases are not visible publicly.

## Public Visibility Rule

A case is visible publicly only if all conditions are true:

```ts
case.status === 'active'
case.verified === true
case.archived_at === null
case.deleted_at === null
```

## Required Fields to Publish/Create a Case

A case requires:

- `case_type`
- `full_name`
- `situation_category_id`
- At least one individual need.
- `id_number`
- At least one Venezuelan phone.
- At least one active assistance method with:
  - `label`
  - `holder_full_name`
  - `id_number`
  - `phone`
  - `bank_name`
  - `account_number`
  - `account_type`
  - `previous_full_address`
  - `current_full_address`

## Case Public Code

Each case must have a human-readable public code:

```txt
RA-000001
RA-000002
RA-000003
```

This code is visible in public and private UI.

## Needs

Each need must be individual.

Correct:

```txt
Olmesartan 40mg
Olmesartan 20mg
Amlodipina 5mg
Levotiroxina 200mg
```

Incorrect:

```txt
Medicinas varias
```

Each need must have:

- Need category.
- Quantity required.
- Optional unit.
- Optional comments.

Needs are not closed by help records. A help record only indicates that help was sent for one or more need items.

## Dynamic Catalogs

These catalogs are auto-expandable:

- `need_categories`
- `situation_categories`
- `help_types`

If a value does not exist, authenticated helpers/admins can create it. Stored normalized values should avoid duplicates.

## Help Records

A help record:

- Is created only by helpers/admins.
- Has exactly one help type.
- Can be associated with one or more case needs.
- Can have optional `amount_usd`.
- Must support manual `helped_at` date.
- Can have public description.
- Can have private notes.
- Is always anonymous publicly.

Public must never see helper/admin identity.

## Assistance Methods

A case can have multiple active assistance methods.

Each assistance method:

- Has a required label.
- Has a type.
- Can be primary.
- Can be active/inactive.
- Must be soft-deletable or deactivated, never hard-deleted.

Public visitors can see all active methods only after clicking the responsible-use flow.

## Responsible Use Flow

Before showing assistance data, display:

```txt
Usa estos datos con responsabilidad. Esta información se muestra únicamente para ayudar a una persona o familia verificada. No compartas estos datos fuera del contexto de ayuda y verifica cuidadosamente antes de transferir o entregar apoyo.
```

## Tracking Access

The system must log:

- Assistance data viewed.
- Assistance data copied.

Store:

- `case_id`
- `assistance_method_id` when available
- `action`
- `ip_hash`
- `user_agent`
- `created_at`

Do not store raw IP addresses.

## Duplicate Detection

During case creation/editing, check duplicates by:

- `id_number`
- Case phones
- Assistance method phones

Duplicate checks must be debounced while typing.

If a possible duplicate exists:

- Show warning.
- Show matching case summary.
- Disable saving until the helper/admin explicitly confirms continuing.

## Archiving

Cases are never hard-deleted.

Archiving requires:

- Confirmation modal.
- Mandatory archive reason.
- Summary of what will be archived.

## Soft Delete

All important data must use soft delete or deactivation where possible.
