# 09 — API and Webhooks

## Public API MVP

The MVP includes a public API for read-only active verified cases.

Public endpoints should never leak private data.

Suggested endpoints:

```txt
GET /api/public/cases
GET /api/public/cases/[id]
POST /api/public/assistance-access-log
```

## GET /api/public/cases

Supports:

- Infinite pagination cursor.
- Randomized ordering per request.
- Search by name/location.
- Filters by state/city/situation/needs.

Returns only public-safe fields.

## GET /api/public/cases/[id]

Returns:

- Case public data.
- Situation.
- Needs.
- Public phones for help flow.
- Public help records.

Does not return assistance method data unless using reveal flow.

## Assistance Reveal

Endpoint:

```txt
POST /api/public/cases/[id]/reveal-assistance-methods
```

This must:

- Run server-side only using `SUPABASE_SERVICE_ROLE_KEY` (anon key has no access to assistance_methods).
- Rate limit by ip_hash (10/min, 30/hour).
- Validate that the case is public (active, verified, not archived, not deleted).
- Log `viewed` action in `assistance_method_access_logs` for each method returned.
- Also return `case_phones` (phones are part of the reveal scope).
- Return active assistance methods and case phones.

## Copy Log

Recommended endpoint/action:

```txt
POST /api/public/assistance-access-log
```

Payload:

```json
{
  "caseId": "uuid",
  "assistanceMethodId": "uuid",
  "action": "copied"
}
```

Server must derive and hash IP.

## Webhooks MVP

MVP scope: **event storage only**. No external HTTP delivery in MVP.

Events to store in `webhook_events`:

- `case.created`
- `case.updated`
- `case.archived`
- `need.created`
- `help_record.created`
- `assistance_method.viewed`
- `assistance_method.copied`

All events are stored with `status = 'disabled'` in MVP so they never attempt delivery.

External delivery (HTTP POST to a configured URL) is a post-MVP feature.

## Email MVP

Email is MVP, but can be minimal.

Use cases:

- Notify admins when a new help record is created.
- Notify admins when assistance data is copied repeatedly.

Implementation can be stubbed with a provider abstraction.

## WhatsApp MVP

WhatsApp is MVP only as generated copy/share text, not API integration.

Do not integrate WhatsApp Business API in MVP.

Provide copy text suitable for WhatsApp.
