# 13 — Roadmap

## MVP

- Person cases.
- Family cases.
- Public grid.
- Public detail.
- Help modal.
- Copy public card.
- Copy assistance data.
- Assistance access logs.
- Admin/helper roles.
- Case CRUD.
- Needs CRUD.
- Dynamic catalogs.
- Register help.
- Manual help date.
- Private notes.
- Audit logs.
- Soft delete.
- Dashboard advanced enough for operations.
- Public API.
- Webhook event storage.
- Email provider abstraction / minimal email.
- WhatsApp copy text.
- Seed Mayreth.

## Post MVP

- Photos.
- Videos.
- Evidence uploads.
- Profile claiming.
- Organizations.
- PDF reports.
- CSV export.
- Notifications.
- Full verification system.
- Donations from web.
- Moderation of changes.
- Timeline audit UI.
- Bank data versioning.
- AI summaries.
- OCR.
- Embeddings.
- Multi-country.
- Multi-language.
- Subdomains.
- Keyboard shortcuts.
- External WhatsApp API integration.
