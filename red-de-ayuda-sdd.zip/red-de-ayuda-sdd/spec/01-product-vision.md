# 01 — Product Vision

## Name

**Red de Ayuda**

## Mission

Create a simple, transparent, verified platform to connect people willing to help with active verified people or family groups in Venezuela.

The platform does not collect money and does not process donations. It only organizes verified aid cases and exposes the minimum public information needed to help responsibly.

## Core Idea

A small trusted group of helpers/admins maintains a database of verified aid cases. The public can browse active cases, see their situation and needs, and request assistance data through an intentional flow.

Every help record is registered anonymously for the public, so people can see whether a case has received help recently and which needs received support.

## Main Trust Principle

The platform should answer three questions clearly:

1. Who needs help?
2. What exactly do they need?
3. When did they last receive help?

## MVP Scope

The MVP must be useful even if implemented quickly. The first version must include:

- Public list of active verified cases.
- Public case detail page.
- Help modal with responsible-use text.
- Assistance method reveal modal.
- Copy public card.
- Copy assistance data.
- Admin/helper login.
- Case creation/editing/archive.
- Family and person cases.
- Need categories as dynamic catalog.
- Situation categories as dynamic catalog.
- Help types as dynamic catalog.
- Help records associated with one or more needs.
- Manual help date.
- Private notes.
- Access logs for view/copy of assistance data.
- Audit logs for important actions.
- Seed case for Mayreth Izturriaga.

## Non-Goals

The MVP must not implement:

- Payment processing.
- Direct donations inside the app.
- Public user registration.
- Beneficiary profile claiming.
- Evidence uploads.
- Photos/videos.
- Organizations.
- Advanced verification workflows.
- Multi-country support.
- Multi-language UI.

## Product Tone

Human, transparent, respectful, low-friction.

The product must avoid feeling like a marketplace or a donation funnel. It is a verified aid registry.
