# 06 — Public Website

## Routes

```txt
/
/someone/[id]
```

## Home Page

The home page shows a random grid of active verified cases.

### Ordering

Each API request should return a different order.

Priority:

1. Cases with zero help records first.
2. Then cases with oldest latest help date.
3. Randomize within priority groups.

### Infinite Scroll

Use infinite scroll.

Do not use classic pagination UI.

### Filters

Public filters:

- State.
- City.
- Situation.
- Needs.

### Search

Public search by:

- Name.
- Location.

Search matches must be highlighted.

## Public Card

Each card must show:

- Public code.
- Full name.
- Case type label: `Persona` or `Familia`.
- Situation.
- General location: city/state/country.
- Needs count.
- Help records count.
- Last help summary.
- Button: `Ayudar`.
- Button: `Copiar ficha`.

## Copy Public Card

The copied text must include:

```txt
Caso verificado en Red de Ayuda

Código: RA-000001
Nombre: Mayreth Izturriaga
Situación: Damnificada
Ubicación: La Guaira, Venezuela

Necesidades:
- Olmesartan 40mg — Cantidad: 1
- Olmesartan 20mg — Cantidad: 1
- Amlodipina 5mg — Cantidad: 1
- Levotiroxina 200mg — Cantidad: 1

Última ayuda registrada: Sin ayudas todavía

Ficha:
https://example.com/someone/{id}
```

## Case Detail Page

The public detail page must show:

- Public code.
- Full name.
- Situation.
- General location.
- Public notes.
- Public contact place.
- Needs list.
- Help history.
- Button: `Ayudar`.
- Button: `Copiar ficha`.

## Help Modal Step 1

Button label:

```txt
Ayudar
```

Modal content:

- Full name.
- Situation.
- Needs.
- Public contact place.
- Phones.
- Responsible-use text.
- Button: `Ver datos para ayudar`.

Responsible-use text:

```txt
Usa estos datos con responsabilidad. Esta información se muestra únicamente para ayudar a una persona o familia verificada. No compartas estos datos fuera del contexto de ayuda y verifica cuidadosamente antes de transferir o entregar apoyo.
```

## Help Modal Step 2

Triggered by `POST /api/public/cases/[id]/reveal-assistance-methods` (server-side, service role).

Shows:

- Case phones (returned by the reveal endpoint alongside assistance methods).
- All active assistance methods.

Each method shows:

- Label.
- Type.
- Holder full name.
- ID number.
- Phone.
- Bank name.
- Account number.
- Account type.
- Previous full address.
- Current full address.

Button:

```txt
Copiar datos
```

The copied text must include:

- Case public code.
- Case full name.
- Situation.
- Needs.
- Assistance method data.

## Logging

When Step 2 is opened:

- Log `viewed` for each assistance method shown or one general reveal event if implementation is simpler.

When copy button is clicked:

- Log `copied` for the specific assistance method.

## Help History Public Display

Help records must be anonymous.

Example:

```txt
Se registró ayuda de tipo medicina para Olmesartan 40mg y Amlodipina 5mg hace 2 días.
Monto registrado: 20 USD.
```

If no amount:

```txt
Se registró ayuda de tipo medicina para Olmesartan 40mg hace 2 días.
```
