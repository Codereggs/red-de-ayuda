# 11 — Development Rules

## Required Tech

- Next.js App Router.
- TypeScript strict mode.
- Supabase.
- React Query.
- Axios.
- React Hook Form.
- Zod.
- Tailwind CSS.

## Do Not Use

- `any` unless unavoidable and documented.
- Public sign-up.
- Hard delete for important data.
- Redux/Zustand in MVP.
- Raw SQL in components.
- Supabase calls directly inside UI components.
- UI copy in English.
- Database names in Spanish.

## Data Fetching

Reads:

- React Query.
- Server Components only where appropriate.

Writes:

- Server Actions.

Supabase access:

- Repository Pattern.

## Validation

All forms must use Zod schemas.

Server Actions must validate again server-side.

## Action Result Shape

Use this shape:

```ts
export type ActionResult<T> =
  | { success: true; data: T }
  | { success: false; error: string; fieldErrors?: Record<string, string[]> };
```

## Error Messages

User-facing errors must be in Spanish.

Developer errors/logs can be in English.

## Environment Variables

Required:

```txt
NEXT_PUBLIC_SUPABASE_URL=
NEXT_PUBLIC_SUPABASE_ANON_KEY=
SUPABASE_SERVICE_ROLE_KEY=
IP_HASH_SECRET=
APP_BASE_URL=
```

Service role key must never be exposed to client components.

## Code Quality

- Keep components small.
- Extract business logic from UI.
- Use typed repositories.
- Use typed DTOs for API responses.
- Use optimistic updates only when safe.
- Invalidate React Query caches after mutations.

## Testing Guidance

MVP minimal tests:

- Zod schema tests.
- Repository tests where feasible.
- Public visibility rule test.
- Duplicate detection utility test.

## Accessibility

- Buttons must be keyboard accessible.
- Modals must trap focus.
- Inputs must have labels.
- Use semantic HTML where possible.
