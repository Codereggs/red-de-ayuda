# 04 — Database Model

## Main Tables

- `profiles`
- `cases`
- `case_private_data`
- `case_phones`
- `assistance_methods`
- `situation_categories`
- `need_categories`
- `case_needs`
- `help_types`
- `help_records`
- `help_record_needs`
- `assistance_method_access_logs`
- `audit_logs`
- `webhook_events`

## Key Design Principles

1. The main domain object is `case`, not `beneficiary`.
2. A case can be a `person` or `family`.
3. Public data and private data are separated.
4. Assistance data is sensitive and access is logged.
5. Help records are public but anonymous.
6. Admin/helper identity is private.
7. All variables, columns, and tables use English.
8. UI is Spanish.

## Entity: profiles

Stores internal users linked to Supabase Auth.

Fields:

- `id`
- `email`
- `full_name`
- `role`
- `status`
- `created_at`
- `updated_at`

Roles:

```txt
admin
helper
```

Statuses:

```txt
active
inactive
```

## Entity: cases

Represents a person or family case.

Fields:

- `id`
- `public_code`
- `case_type`
- `full_name`
- `situation_category_id`
- `public_notes`
- `public_contact_place`
- `country`
- `state`
- `city`
- `status`
- `verified`
- `created_by_user_id`
- `updated_by_user_id`
- `archived_by_user_id`
- `archive_reason`
- `archived_at`
- `deleted_at`
- `created_at`
- `updated_at`

Case types:

```txt
person
family
```

Statuses:

```txt
active
archived
```

## Entity: case_private_data

Private data visible only to active helpers/admins.

Fields:

- `id`
- `case_id`
- `id_number`
- `birth_date`
- `previous_full_address`
- `current_full_address`
- `verification_notes`
- `private_notes`
- `created_at`
- `updated_at`
- `deleted_at`

No sex/gender field in MVP.

## Entity: case_phones

Stores phones associated with a case.

Fields:

- `id`
- `case_id`
- `phone`
- `label`
- `is_primary`
- `created_at`
- `updated_at`
- `deleted_at`

Labels are optional free text.

## Entity: assistance_methods

Stores ways to help the case.

Fields:

- `id`
- `case_id`
- `type`
- `label`
- `is_primary`
- `is_active`
- `holder_full_name`
- `id_number`
- `phone`
- `bank_name`
- `account_number`
- `account_type`
- `previous_full_address`
- `current_full_address`
- `notes`
- `created_at`
- `updated_at`
- `deleted_at`

Types:

```txt
bank_transfer
pago_movil
cash_contact
physical_delivery
```

No `other` option in MVP.

## Entity: situation_categories

Dynamic catalog.

Fields:

- `id`
- `name`
- `normalized_name`
- `created_by_user_id`
- `created_at`
- `updated_at`
- `deleted_at`

Examples:

- `damnificada`
- `caso medico`
- `adulto mayor`
- `familia con ninos`
- `perdida de vivienda`

## Entity: need_categories

Dynamic catalog.

Fields:

- `id`
- `name`
- `normalized_name`
- `created_by_user_id`
- `created_at`
- `updated_at`
- `deleted_at`

Examples:

- `olmesartan 40mg`
- `amlodipina 5mg`
- `levotiroxina 200mg`
- `comida`
- `panales`

## Entity: case_needs

A specific need assigned to a case.

Fields:

- `id`
- `case_id`
- `need_category_id`
- `quantity`
- `unit`
- `comments`
- `created_by_user_id`
- `created_at`
- `updated_at`
- `deleted_at`

Quantity is required.

Unit is optional.

Need status is intentionally omitted in MVP because help records do not close needs.

## Entity: help_types

Dynamic catalog for help record type.

Fields:

- `id`
- `name`
- `normalized_name`
- `created_by_user_id`
- `created_at`
- `updated_at`
- `deleted_at`

Examples:

- `medicine`
- `transfer`
- `food`
- `transport`
- `clothes`

No `other` type.

## Entity: help_records

Represents one anonymous public help action.

Fields:

- `id`
- `case_id`
- `help_type_id`
- `created_by_user_id`
- `title`
- `description`
- `amount_usd`
- `helped_at`
- `private_notes`
- `created_at`
- `updated_at`
- `deleted_at`

Public can see:

- title
- description
- amount_usd if present
- helped_at
- associated needs

Public cannot see:

- created_by_user_id
- private_notes

## Entity: help_record_needs

Many-to-many relation between help records and case needs.

Fields:

- `id`
- `help_record_id`
- `case_need_id`
- `created_at`

## Entity: assistance_method_access_logs

Tracks view/copy actions for assistance data.

Fields:

- `id`
- `case_id`
- `assistance_method_id`
- `action`
- `ip_hash`
- `user_agent`
- `created_at`

Actions:

```txt
viewed
copied
```

Never store raw IP.

## Entity: audit_logs

Tracks important private actions.

Fields:

- `id`
- `actor_user_id`
- `entity_type`
- `entity_id`
- `action`
- `old_values`
- `new_values`
- `metadata`
- `created_at`

Audit logs are admin-only in MVP.

## Entity: webhook_events

Stores webhook deliveries/events.

Fields:

- `id`
- `event_type`
- `payload`
- `status`
- `attempts`
- `last_error`
- `created_at`
- `updated_at`

MVP can store events even if delivery is minimal.
