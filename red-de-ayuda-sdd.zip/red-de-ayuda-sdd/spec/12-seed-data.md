# 12 — Seed Data

## Seed Case: Mayreth Izturriaga

This seed is based on the first real case used for the MVP.

## Case

```txt
case_type: person
full_name: Mayreth Izturriaga
situation: Damnificada
country: Venezuela
state: La Guaira
city: Marapa Marina
public_contact_place: Liceo Carlos Fiol, en Marapa Marina
verified: true
status: active
```

## Private Data

```txt
id_number: V-00000000
previous_full_address: Estado La Guaira, localidad Marapa Marina, calle/casa pendiente por confirmar
current_full_address: Liceo Carlos Fiol, Marapa Marina
verification_notes: Caso cargado inicialmente para prueba del MVP. Datos sensibles incompletos deben ser confirmados por helpers.
private_notes: Seed inicial. Completar cédula y direcciones reales antes de usar en producción.
```

## Phones

```txt
04242938593
04166314314
```

## Situation Category

```txt
Damnificada
```

## Need Categories

```txt
Olmesartan 40mg
Olmesartan 20mg
Amlodipina 5mg
Levotiroxina 200mg
```

## Case Needs

Each quantity should be `1` initially because exact required quantity is unknown.

```txt
Olmesartan 40mg — quantity: 1 — unit: caja
Olmesartan 20mg — quantity: 1 — unit: caja
Amlodipina 5mg — quantity: 1 — unit: caja
Levotiroxina 200mg — quantity: 1 — unit: caja
```

## Assistance Method

Use placeholder values where real data is missing.

```txt
type: bank_transfer
label: Datos para transferencia
holder_full_name: Mayreth Izturriaga
id_number: V-00000000
phone: 04242938593
bank_name: PENDIENTE
account_number: PENDIENTE
account_type: PENDIENTE
previous_full_address: Estado La Guaira, localidad Marapa Marina, calle/casa pendiente por confirmar
current_full_address: Liceo Carlos Fiol, Marapa Marina
is_primary: true
is_active: true
```

## Important Seed Warning

Do not use placeholder bank data publicly in production.

Seed is for local/dev validation only unless completed with verified real data.
