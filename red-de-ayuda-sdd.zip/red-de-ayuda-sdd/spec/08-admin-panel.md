# 08 — Admin Panel

## Routes

```txt
/dashboard/users
/dashboard/logs
```

## User Management

Users are created manually in Supabase Auth for MVP.

The app must allow admins to manage `profiles` records:

- Full name.
- Email.
- Role.
- Status.

Roles:

```txt
admin
helper
```

Statuses:

```txt
active
inactive
```

Inactive profiles must not have internal access.

## Access Logs

Admin can view assistance method access logs.

Show:

- Case public code.
- Case full name.
- Assistance method label.
- Action: viewed/copied.
- IP hash.
- User agent.
- Created at.

## Audit Logs

Admin can view audit logs.

Show:

- Actor.
- Entity type.
- Entity ID.
- Action.
- Old values.
- New values.
- Metadata.
- Created at.

## Help Record Traceability

Public help records are anonymous.

Admin/private view can show:

- Which helper/admin created it.
- Created at.
- Private notes.

## Admin Safety

Do not expose raw secrets, service role keys, or raw IP addresses in admin UI.
