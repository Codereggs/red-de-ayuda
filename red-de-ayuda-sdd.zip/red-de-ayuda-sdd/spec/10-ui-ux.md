# 10 — UI / UX

## Language

All user-facing UI must be in Spanish.

Code/database must be in English.

## Theme

Dark mode only.

Design should feel:

- Human.
- Calm.
- Trustworthy.
- Simple.
- Mobile first.

## Responsive Behavior

Desktop:

- Use toasts for feedback.
- Use modals for confirmations.

Mobile:

- Use drawer/sheet for feedback and dense flows.
- Modals may become bottom sheets.

## Required Components

- Button.
- Input.
- Textarea.
- Combobox.
- Badge.
- Card.
- Modal.
- Drawer.
- Toast.
- Skeleton.
- Empty state.
- Confirm dialog.
- Data table.
- HighlightedText for search matches.

## Skeletons

Use skeleton loading states for:

- Public grid.
- Public detail.
- Dashboard cards.
- Private tables.
- Form initial loading.

## Forms

Use:

- React Hook Form.
- Zod.
- Disabled save until form is valid.
- Inline validation messages.
- Duplicate detection indicators.

## Confirmation Modals

Required for:

- Archive case.
- Deactivate assistance method.
- Inactivate user.

Archive modal must show summary and require reason.

## Copy UX

When copying public card or assistance data:

- Show success feedback.
- Log sensitive assistance method copy.

## Public Labels

Use these labels:

```txt
Ayudar
Copiar ficha
Ver datos para ayudar
Copiar datos
Necesidades
Historial de ayuda
Última ayuda
Sin ayudas todavía
Caso verificado
Persona
Familia
```

## Private Labels

Use these labels:

```txt
Panel
Casos
Crear caso
Editar caso
Archivar caso
Registrar ayuda
Marcar ayuda
Datos privados
Métodos de ayuda
Notas privadas
Historial de accesos
Usuarios
```

## Search Highlighting

Any search result should highlight matching text.

Applies to:

- Public search.
- Private global search.
