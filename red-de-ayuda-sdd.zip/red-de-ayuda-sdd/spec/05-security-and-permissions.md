# 05 — Security and Permissions

## Security Principles

1. Supabase RLS must be enabled for all app tables.
2. Public users only see safe public data.
3. Private data is restricted to active authenticated helpers/admins.
4. Help records are public but anonymous.
5. Assistance method access must be logged.
6. Admin-only data must not leak through public APIs.
7. Never store raw IP addresses.

## Public Access

Public can read:

- `cases` where active, verified, not archived, not deleted.
- `situation_categories` used by public cases.
- `need_categories` used by public cases.
- `case_needs` for public cases.
- `help_types` used by public help records.
- `help_records` for public cases, excluding private fields.
- `help_record_needs` for public cases.
- `case_phones` only during help flow if included in response intentionally.
- Active `assistance_methods` only through dedicated reveal flow.

Public cannot read directly:

- `profiles`
- `case_private_data`
- `audit_logs`
- `webhook_events`
- `created_by_user_id` details
- `private_notes`

## Authenticated Helper/Admin Access

Active helpers/admins can read and write app data according to role.

Helpers can:

- Manage cases.
- Manage needs.
- Manage phones.
- Manage assistance methods.
- Register help records.
- Read private data.

Admins can additionally:

- Manage profiles.
- View audit logs.
- View access logs dashboard.

## Profile Status

All permissions require:

```sql
profiles.status = 'active'
```

Inactive users must lose access even if they still have a Supabase Auth session.

## Assistance Method Access

All public access to assistance method data must go through the server-side
reveal endpoint using the service role key. The anon key has no SELECT access
to `assistance_methods`. This ensures the access log cannot be bypassed.

The reveal endpoint also returns `case_phones` for the help modal. Phones are
considered contact-sensitive data and are part of the reveal scope.

## Assistance Method Logging

When public or authenticated users view or copy assistance method data, insert into `assistance_method_access_logs`.

Store:

- `case_id`
- `assistance_method_id`
- `action`
- `ip_hash`
- `user_agent`

## IP Hashing

Hash IP server-side before storing.

Recommended approach:

```txt
sha256(ip + server_secret)
```

Never store the raw IP in database.

## Rate Limiting

MVP must include a lightweight rate limiter for sensitive public endpoints:

- Assistance method reveal.
- Assistance method copy log.

Limits (enforced server-side per `ip_hash`):

- Max **10 reveal requests per minute** per ip_hash.
- Max **30 reveal requests per hour** per ip_hash.
- Return HTTP 429 with generic error message in Spanish:
  ```txt
  Demasiadas solicitudes. Por favor espera un momento antes de intentarlo nuevamente.
  ```

Implementation: in-memory or edge KV store (e.g. Upstash Redis). Do not store raw IP.

## Login Security

Use Supabase Auth.

Users are created manually in Supabase for MVP.

No public sign-up.

## Sensitive UI Warnings

Before showing assistance data, show responsible-use text:

```txt
Usa estos datos con responsabilidad. Esta información se muestra únicamente para ayudar a una persona o familia verificada. No compartas estos datos fuera del contexto de ayuda y verifica cuidadosamente antes de transferir o entregar apoyo.
```

## RLS Helper Functions

Create helper SQL functions:

- `is_active_internal_user()`
- `is_admin()`
- `is_helper_or_admin()`

## Soft Delete

Use `deleted_at` or `archived_at`.

Avoid hard delete for important records.
